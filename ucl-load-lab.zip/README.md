# UCL Load Lab

Elbow (UCL) stress and injury risk in baseball pitchers, from motion capture and physics.

- **3D replay** of two real deliveries rebuilt from motion capture: same velocity, very different elbow load.
- **Build your pitcher**: drag a real pitcher's arm, elbow and trunk into new mechanics, watch the throw, see elbow torque change.
- **Every 2026 MLB pitcher** (1,000+ pitches) on one map: real pitch counts × elbow stress.
- **Calculator**: fastball speed, weight, height, pitch count → modeled season risk.

## Put it online (2 minutes, no coding)

The website is the `public/` folder. It's plain files, no build step.

**Vercel (easiest)**
1. Go to **vercel.com/drop** and sign in (free account).
2. Drag in `ucl-load-lab-site.zip` (or the `public` folder).
3. Name the project and click **Deploy**. You get a live link.

**Cloudflare Pages**
1. Cloudflare dashboard → **Workers & Pages** → **Create application** → **Get started** →
   **Drag and drop your files**.
2. Name the project, drop `ucl-load-lab-site.zip`, click **Deploy site**.
3. Your link is `<project-name>.pages.dev`.

To update later, upload the new zip as a new deployment of the same project.

## Results

| | |
|---|---|
| My elbow torque vs the lab's own inverse dynamics | r = 0.90, bias −2.1 Nm (397 clean pitches) |
| Mean peak elbow varus torque | 109 Nm, ~5.5 ms before max layback |
| Velocity + body size explain (unseen pitchers) | R² = 0.37; adding six mechanics → 0.48 |
| Strongest mechanical signal | more layback ↔ less torque at the same velocity (r = −0.43) |
| Build your pitcher (per unit, same speed and size) | layback −0.72 Nm/°, elbow bend +0.37, trunk tilt +0.31, arm slot −0.14 (≈ 0) |
| UCL share of elbow torque (calibrated) | 9.3% (≈12 Nm per pitch for an average MLB arm) |
| **+10% elbow torque** | **same fatigue damage as 2.1× the pitch count** |
| 2026 MLB, 266 pitchers | median modeled season risk 3.0% (starters 3.9%, relievers 2.1%) |

## How it works

1. **Physics.** Newton–Euler inverse dynamics of the forearm, hand and ball (de Leva segment
   parameters) on 360 Hz joint-center trajectories gives peak elbow varus torque per pitch.
2. **Mechanics.** Grouped-by-pitcher cross-validated models find what drives that torque.
3. **Risk.** The UCL wears out with each pitch: stress S = UCL load / ligament strength,
   cycles to failure from human tendon fatigue (S = 101.3 − 14.8 log₁₀N), damage added with
   Miner's rule, ligament strength varying between people (log-normal, scaled with body
   mass^(2/3)). The UCL's share of the torque is calibrated so an average MLB arm (94.8 mph,
   2,500 pitches) has ~5% season risk, in line with ~49 MLB UCL injuries a year.
4. **Build your pitcher.** A real delivery is re-posed with rigid rotations (trunk about the hips, arm about the
   shoulder, forearm about the upper arm and elbow) so the measured mechanics hit your targets; bones keep their length.
   Torque = that pitch's real physics + the lab model's change for your mechanics (association, not cause).
5. **MLB.** 2026 pitch counts, heights and weights (MLB Stats API) and fastball speed
   (Baseball Savant) → estimated torque from the size + velocity model → stress → risk.

## Files

```
public/                 the website — deploy this
  index.html            page + 3D replay (three.js) + charts + calculator
  model.js              risk math in JS (matches the Python to <0.001%)
  build.js              re-poses a real delivery for "Build your pitcher"
  data/                 site.json, anim.json (two mocap deliveries), mlb.json (2026 MLB), build.json
  vendor/three.min.js   three.js r149 (MIT)
  fonts/                Ubuntu, Ubuntu Condensed, Ubuntu Mono (self-hosted fallback)
pipeline/
  fetch_data.py         download + checksum-verify OpenBiomechanics data
  physics.py            the physics engine
  compute_physics.py    torque, force, energy, sequence for every pitch
  model_stress.py       which mechanics drive elbow torque
  risk_model.py         UCL fatigue-failure model and calibration
  fetch_mlb.py          re-download the MLB season table (optional)
  mlb.py                score every MLB pitcher
  export_site.py        write public/data
  build_model.py        mechanics → torque model and the base delivery for "Build your pitcher"
  build_check.js        checks the re-posed motion hits the requested angles
  run_all.sh            run everything
experiments/video/      can a phone video measure these mechanics? (not yet; see its README)
data/                   small derived outputs + mlb_2026.csv
```

Rebuild from scratch:

```bash
pip install -r pipeline/requirements.txt
bash pipeline/run_all.sh                    # ~3 min, downloads ~240 MB once
cd public && python3 -m http.server 8000    # preview at http://localhost:8000
```

Opening `index.html` by double-clicking won't load the data; use a server as above or deploy it.

## Limits

The motion-capture pitchers are anonymous with no injury records, so risk is calibrated to
league rates, not validated on outcomes. MLB estimates assume average mechanics and ignore rest,
back-to-back outings, strength and fatigue (likely understating relievers). Tendon stands in for
ligament in the fatigue curve. **Not medical advice.**

## Credits and license

Motion data: [Driveline OpenBiomechanics Project](https://github.com/drivelineresearch/openbiomechanics),
**CC BY-NC-SA 4.0**. This project's derived data and site are shared under the same license
(non-commercial, attribution, share-alike). MLB data: MLB Stats API and Baseball Savant.
three.js: MIT. Ubuntu fonts: Ubuntu Font Licence.

References: Fleisig et al. 1995 (AJSM); Anz et al. 2010 (AJSM); Morrey & An 1983 (AJSM);
Schechtman & Bader 1997 (J Biomech); van Trigt, Veeger et al. 2020 (Proceedings 49:107);
Buffi et al. 2015 (Ann Biomed Eng); Dillon et al. 2026 (OJSM); de Leva 1996 (J Biomech).
